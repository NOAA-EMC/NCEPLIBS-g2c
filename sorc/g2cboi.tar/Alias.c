/* a list of aliases
 *
 * public domain 2/2007 Wesley Ebisuzaki
 */


/*
 * HEADER:200:disc=f_code_table_0_0:inv:0:discipline (code table 0.0)
 * HEADER:-1:v1=f_v:misc:0:verbose (v=1)
 * HEADER:-1:quit=f_end:misc:0:stop after first (sub)message (save time)
 */
